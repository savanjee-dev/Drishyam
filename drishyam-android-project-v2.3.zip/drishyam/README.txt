Drishyam Android project — Version 2.2 (versionCode 8)

WHAT CHANGED IN 2.2 (includes everything from 2.1)
- Live glass: the header, bottom bar, status pill, viewer info panel and pop-ups copy the picture behind them, blur it, boost its colour, and draw it with a tint, a light sheen and a lit rim. It works on every Android version this app supports, not only Android 12+.
- Floating bars: the header and the bottom bar float over the feed. Photos scroll underneath and show through the glass.
- Pop-ups: search, What's new, Credits and the wallpaper chooser are glass cards inside the screen, with margins on every side, dimmed background and a spring pop-in. Back closes them.
- Photo viewer: the photo fills the screen; the info panel is dark glass over it. Camera details show as one line and only when the source provides them.
- Safety: if the live blur is slow on a phone, it refreshes less often, then switches itself off and shows a static frosted look. Low-effects mode in Settings turns it off completely.

FILES OF NOTE
- app/src/main/java/com/savan/drishyam/GlassLayout.kt — the live glass panel (capture, blur, rim, fallback)
- app/src/main/java/com/savan/drishyam/Fx.kt — tap feedback, glass pop-ups, glass binding
- app/src/main/res/layout/activity_main.xml — floating glass bars
- app/src/main/res/layout/activity_viewer.xml — full-screen viewer and glass panel
- app/src/main/res/values/colors.xml and values-night/colors.xml — glass tint and rim colours
- app/src/main/res/values/attrs.xml — glassRadius and glassDark options for glass panels

FIREBASE / CI
- The build expects repository secret GOOGLE_SERVICES_JSON.
- Ship only one project zip in the repository root; the build uses the highest version number.

CLOUDINARY / GALLERY — NOT YET INTEGRATED
- Gallery by Savan is shown as in development.

NOT BUILD-TESTED IN THIS ENVIRONMENT
- No Android SDK or Gradle is available where this source was prepared. Test on a phone after the GitHub build.
