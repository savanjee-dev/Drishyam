package com.savan.drishyam

import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.google.android.material.materialswitch.MaterialSwitch

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        MainActivity.applyTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        val prefs = getSharedPreferences(PREFS_SETTINGS, Context.MODE_PRIVATE)

        findViewById<View>(R.id.settingsBack).apply { pressFx(); setOnClickListener { finish() } }

        // Theme pills
        val themes = listOf(R.id.themeSystem to "System", R.id.themeDark to "Dark", R.id.themeLight to "Light")
        fun paintTheme() {
            val current = prefs.getString("theme", "System")
            themes.forEach { (id, v) -> findViewById<TextView>(id).styleSeg(current == v) }
        }
        themes.forEach { (id, v) ->
            findViewById<TextView>(id).apply {
                pressFx()
                setOnClickListener {
                    prefs.edit().putString("theme", v).apply()
                    MainActivity.applyTheme(this@SettingsActivity)
                    paintTheme()
                }
            }
        }
        paintTheme()

        // Toggles
        val haptic = findViewById<MaterialSwitch>(R.id.swHaptics)
        haptic.isChecked = hapticsOn(this)
        haptic.setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("haptics", on).apply() }

        val lowFxSwitch = findViewById<MaterialSwitch>(R.id.swLowFx)
        lowFxSwitch.isChecked = lowFx(this)
        lowFxSwitch.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean("low_fx", on).apply()
            recreate()
        }

        // Default feed order pills
        val sorts = listOf(R.id.sortHotS to "hot", R.id.sortNewS to "new", R.id.sortTopS to "top")
        fun paintSort() {
            val current = prefs.getString("sort", "hot")
            sorts.forEach { (id, v) -> findViewById<TextView>(id).styleSeg(current == v) }
        }
        sorts.forEach { (id, v) ->
            findViewById<TextView>(id).apply {
                pressFx()
                setOnClickListener { prefs.edit().putString("sort", v).apply(); paintSort() }
            }
        }
        paintSort()

        // Action rows
        findViewById<View>(R.id.rowClear).apply {
            pressFx()
            setOnClickListener {
                Glide.get(this@SettingsActivity).clearMemory()
                Thread {
                    Glide.get(applicationContext).clearDiskCache()
                    runOnUiThread { Toast.makeText(this@SettingsActivity, getString(R.string.cache_cleared), Toast.LENGTH_SHORT).show() }
                }.start()
            }
        }
        findViewById<View>(R.id.rowWhatsNew).apply {
            pressFx()
            setOnClickListener { messagePopup(this@SettingsActivity, findViewById(R.id.glassSource), getString(R.string.whats_new_title), getString(R.string.whats_new_body)) }
        }
        findViewById<View>(R.id.rowCredits).apply {
            pressFx()
            setOnClickListener { messagePopup(this@SettingsActivity, findViewById(R.id.glassSource), getString(R.string.credits_title), getString(R.string.credits_body)) }
        }

        findViewById<TextView>(R.id.settingsVersion).text = getString(R.string.settings_version)
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (!PopupStack.dismiss()) super.onBackPressed()
    }
}
