package com.savan.drishyam

import android.animation.ValueAnimator
import android.content.Intent
import android.content.res.Resources
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Shader
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.material.card.MaterialCardView

fun Int.dp(): Int = (this * Resources.getSystem().displayMetrics.density).toInt()

class Source(val name: String, val unsplash: Boolean, val q: String) {
    val items = ArrayList<Photo>()
    val ids = HashSet<String>()
    var after = ""
    var page = 1
    var done = false
    var loading = false
    var err: String? = null
}

class MainActivity : AppCompatActivity() {
    private lateinit var rv: RecyclerView
    private lateinit var status: TextView
    private lateinit var chips: LinearLayout
    private lateinit var chipScroll: View
    private val adapter = PhotoAdapter()
    private val sources = ArrayList<Source>()
    private lateinit var cur: Source
    private var tab = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        rv = findViewById(R.id.rv)
        status = findViewById(R.id.status)
        chips = findViewById(R.id.chips)
        chipScroll = findViewById(R.id.chipScroll)

        animateTitle()

        if (Config.UNSPLASH_KEY.isNotBlank()) {
            for ((n, q) in listOf("Unsplash" to "wallpaper", "Nature" to "nature wallpaper", "Abstract" to "abstract wallpaper",
                "Dark" to "dark amoled wallpaper", "Minimal" to "minimal wallpaper", "City" to "city night wallpaper", "Space" to "space wallpaper"))
                sources.add(Source(n, true, q))
        }
        for (s in listOf("incredibleindia", "india_tourism", "cloud", "beach", "Earth", "river", "sky", "forest",
            "hiking", "photographs", "backpack", "mountain", "mobilephotography", "wildlifephotography"))
            sources.add(Source("r/$s", false, s))
        cur = sources[0]

        rv.layoutManager = LinearLayoutManager(this, RecyclerView.VERTICAL, false)
        rv.adapter = adapter
        rv.setHasFixedSize(true)
        rv.setItemViewCacheSize(8)
        rv.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(r: RecyclerView, dx: Int, dy: Int) {
                val lm = r.layoutManager as LinearLayoutManager
                if (dy > 0 && lm.findLastVisibleItemPosition() >= adapter.itemCount - 4) loadMore()
            }
        })
        status.setOnClickListener { if (tab == 0 && cur.err != null) { cur.err = null; loadMore() } }

        buildChips()
        findViewById<View>(R.id.n0).setOnClickListener { showTab(0) }
        findViewById<View>(R.id.n1).setOnClickListener { showTab(1) }
        findViewById<View>(R.id.n2).setOnClickListener { showTab(2) }
        findViewById<View>(R.id.ig).setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://instagram.com/savanjee")))
        }
        showTab(0)
    }

    override fun onResume() {
        super.onResume()
        if (tab == 1) { adapter.data = Store.favs(this); adapter.notifyDataSetChanged(); updateStatus() }
        else adapter.notifyDataSetChanged()
    }

    private fun animateTitle() {
        val t = findViewById<TextView>(R.id.title)
        t.post {
            val w = t.paint.measureText(t.text.toString()).coerceAtLeast(100f) * 2
            val colors = intArrayOf(0xFFFF9966.toInt(), 0xFFFF5E62.toInt(), 0xFFC04BFF.toInt(), 0xFF5B8CFF.toInt(), 0xFFFF9966.toInt())
            val sh = LinearGradient(0f, 0f, w, 0f, colors, null, Shader.TileMode.REPEAT)
            t.paint.shader = sh
            val m = Matrix()
            ValueAnimator.ofFloat(0f, w).apply {
                duration = 5000
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                addUpdateListener { m.setTranslate(it.animatedValue as Float, 0f); sh.setLocalMatrix(m); t.invalidate() }
                start()
            }
        }
    }

    private fun buildChips() {
        chips.removeAllViews()
        for (s in sources) {
            val tv = TextView(this)
            tv.text = s.name
            tv.textSize = 14f
            tv.setPadding(18.dp(), 0, 18.dp(), 0)
            tv.gravity = android.view.Gravity.CENTER
            tv.tag = s
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, 40.dp())
            lp.marginEnd = 8.dp()
            tv.layoutParams = lp
            tv.setOnClickListener { select(s) }
            chips.addView(tv)
        }
        styleChips()
    }

    private fun styleChips() {
        for (i in 0 until chips.childCount) {
            val tv = chips.getChildAt(i) as TextView
            val on = tv.tag === cur
            tv.setBackgroundResource(if (on) R.drawable.pill_fg else R.drawable.pill_chip)
            tv.setTextColor(getColor(if (on) R.color.bg else R.color.fg))
        }
    }

    private fun select(s: Source) {
        cur = s
        tab = 0
        styleChips()
        adapter.data = s.items
        adapter.notifyDataSetChanged()
        rv.scrollToPosition(0)
        updateStatus()
        if (s.items.isEmpty()) loadMore()
    }

    private fun showTab(n: Int) {
        tab = n
        val ids = intArrayOf(R.id.n0, R.id.n1, R.id.n2)
        for (i in 0..2) {
            val v = findViewById<TextView>(ids[i])
            v.setBackgroundResource(if (i == n) R.drawable.pill_accent else 0)
            v.setTextColor(if (i == n) 0xFFFFFFFF.toInt() else getColor(R.color.mute))
        }
        findViewById<View>(R.id.home).visibility = if (n < 2) View.VISIBLE else View.GONE
        findViewById<View>(R.id.about).visibility = if (n == 2) View.VISIBLE else View.GONE
        chipScroll.visibility = if (n == 0) View.VISIBLE else View.GONE
        if (n == 1) adapter.data = Store.favs(this) else if (n == 0) adapter.data = cur.items
        adapter.notifyDataSetChanged()
        updateStatus()
        if (n == 0 && cur.items.isEmpty()) loadMore()
    }

    private fun updateStatus() {
        status.text = when {
            tab == 1 -> if (Store.favs(this).isEmpty()) "Nothing saved yet. Tap ♡ on a wallpaper." else ""
            cur.loading -> "Loading more…"
            cur.err != null -> cur.err + " Tap to retry."
            cur.done -> "You’ve reached the end"
            else -> ""
        }
    }

    private fun loadMore() {
        val s = cur
        if (tab != 0 || s.loading || s.done || s.err != null) return
        s.loading = true
        updateStatus()
        Thread {
            var added = ArrayList<Photo>()
            try {
                if (s.unsplash) {
                    val (list, last) = Api.unsplash(s.q, s.page)
                    s.page++
                    if (last) s.done = true
                    added.addAll(list)
                } else {
                    try {
                        val (list, next) = Api.reddit(s.q, s.after)
                        s.after = next
                        if (next.isEmpty()) s.done = true
                        added.addAll(list)
                        // If Reddit returned an empty page, don't spin on the same page.
                        if (list.isEmpty() && next.isEmpty()) s.done = true
                    } catch (redditError: Exception) {
                        val message = redditError.message.orEmpty()
                        if (message.contains("403") || message.contains("429") || message.contains("Forbidden", true)) {
                            val (fallback, last) = Api.commons(s.q, s.page)
                            s.page++
                            if (last) s.done = true
                            added.addAll(fallback)
                        } else throw redditError
                    }
                }
            } catch (e: Exception) {
                val m = e.message ?: ""
                s.err = when {
                    m.contains("429") -> "Reddit is rate-limiting requests (HTTP 429), and the fallback source could not load. Tap to retry."
                    m.contains("403") -> "Reddit refused the request, and the fallback source could not load. Check your connection and retry."
                    m.contains("404") -> "This Reddit feed was not found (HTTP 404)."
                    m.contains("UnknownHost") || m.contains("timeout", true) || m.contains("Unable to resolve", true) -> "Network unavailable. Check your internet and retry."
                    else -> "Couldn’t load photos ($m). Tap to retry."
                }
            }
            runOnUiThread {
                s.loading = false
                val fresh = added.filter { s.ids.add(it.id) }
                val start = s.items.size
                s.items.addAll(fresh)
                if (s === cur && tab == 0) {
                    adapter.notifyItemRangeInserted(start, fresh.size)
                    updateStatus()
                    rv.post { if (!rv.canScrollVertically(1)) loadMore() }
                }
            }
        }.start()
    }

    inner class PhotoAdapter : RecyclerView.Adapter<PhotoAdapter.VH>() {
        var data: List<Photo> = ArrayList()

        inner class VH(val root: View) : RecyclerView.ViewHolder(root) {
            val img: ImageView = root.findViewById(R.id.img)
            val lbl: TextView = root.findViewById(R.id.lbl)
            val heart: TextView = root.findViewById(R.id.heart)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_photo, parent, false)
            v.layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                setMargins(0, 8.dp(), 0, 12.dp())
            }
            return VH(v)
        }

        override fun getItemCount() = data.size

        override fun onBindViewHolder(h: VH, pos: Int) {
            val p = data[pos]
            h.lbl.text = p.credit.ifBlank { "Photographer" }
            h.heart.text = if (Store.isFav(this@MainActivity, p.id)) "♥" else "♡"
            val screenWidth = Resources.getSystem().displayMetrics.widthPixels - 36.dp()
            val ratio = if (p.width > 0 && p.height > 0) p.height.toFloat() / p.width.toFloat() else 1.18f
            val desiredHeight = (screenWidth * ratio).toInt().coerceIn(190.dp(), 650.dp())
            h.img.layoutParams = h.img.layoutParams.apply { height = desiredHeight }
            h.img.setBackgroundColor(p.color)
            Glide.with(h.img).load(p.thumb).centerCrop().into(h.img)
            h.heart.setOnClickListener {
                val liked = Store.toggle(this@MainActivity, p)
                if (tab == 1) { data = Store.favs(this@MainActivity); notifyDataSetChanged(); updateStatus() }
                else h.heart.text = if (liked) "♥" else "♡"
            }
            h.root.setOnClickListener {
                startActivity(Intent(this@MainActivity, ViewerActivity::class.java).putExtra("p", p.toJson().toString()))
            }
        }
    }
}
