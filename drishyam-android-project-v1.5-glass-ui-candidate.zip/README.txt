Drishyam Android project

Package: com.savan.drishyam
Version: 1.3 (versionCode 3)

Changes in this source update
- Replaced two-column GridLayoutManager with a single-column vertical feed.
- Feed cards adapt their height to available source image dimensions where provided; portrait and landscape images keep their proportions.
- Added r/india_tourism and requested subreddit sources: r/hiking, r/photographs, r/backpack, r/mountain, r/mobilephotography, r/wildlifephotography.
- Image details page now follows the supplied reference structure more closely and shows photographer/source, published date when available, and dimensions when supplied by the source.
- Tapping the image on the details page opens a separate immersive full-screen viewer.
- Added persistent bookmark support alongside favourites/likes.
- Increased version to 1.3.

Firebase build configuration
- GitHub Actions expects repository secret GOOGLE_SERVICES_JSON.
- The workflow writes that secret to app/google-services.json only during build.
- Do not commit google-services.json or any Cloudinary API secret to this public repository.

Cloudinary status — NOT YET FULLY INTEGRATED
- About now includes a Gallery by Savan section, but public gallery retrieval and developer upload/edit/delete are not yet wired to a backend.
- Because the supplied upload preset is signed, a trusted backend must generate signatures and verify Firebase developer authorization. This cannot be safely done using only the cloud name and upload preset in the Android client.
- Do not put Cloudinary API secret in Android code or this public repository. Configure it as a backend secret after backend deployment.

Not build-tested in this environment
- This environment has no Android SDK/Gradle executable available for a complete Android build.
- Run the GitHub Actions build and inspect the result before installing this APK.


Version 1.5 UI candidate: shared rounded glass dialog theme, glass-pill search/settings/navigation controls, and refined photo-detail action sizing. This is a source candidate and must be built and device-tested before release.
