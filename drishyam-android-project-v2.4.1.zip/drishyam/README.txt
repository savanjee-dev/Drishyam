Drishyam Android project — Version 2.4.1 (versionCode 12)

WHAT CHANGED IN 2.4.1
- Corrected app version labels throughout Settings and About.
- Includes a GitHub Releases update checker at launch and a manual Check for updates action under Settings > About.
- Includes release notes in the in-app update dialog and downloads the APK through Android DownloadManager, requiring user approval to install.
- Retains the current Drishyam interface, creator profile, fonts, feed behavior, and visual styling from the prepared source.
- Application ID remains com.savan.drishyam.

PUBLISHING UPDATES
- Releases are built and published by the repository workflow.
- Keep the same signing key for every release; never commit the keystore or passwords.
- Increment versionCode and update versionName and the matching changelog for every future release.
- Android installation requires matching application ID and signing certificate, plus a higher versionCode.

The app checks the latest public GitHub Release at launch. A newer release with an APK asset can trigger an in-app changelog dialog. The user downloads the APK and confirms installation through Android.
