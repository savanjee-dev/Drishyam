Drishyam Android project — Version 2.0 (versionCode 6)

WHAT CHANGED IN 2.0
- Full glass redesign. Search (purple border) and Settings (pink border) are frosted-glass pills with matching icons.
- Animated backdrop: three soft colour orbs drift slowly behind every screen.
- Press feedback: controls squish on touch, spring back on release, and give light tap feedback (can be turned off in Settings).
- About page: photo in a glowing halo over a blurred copy of the same photo. The blur is a real GPU blur on Android 12+; older phones show the photo with a soft fade instead.
- Typography: Erica One for the app title, Nothing You Could Do for names and photo credits, system sans for interface text, monospace for camera data and version.
- Saved tab now has two pills: Likes and Bookmarks (bookmarks had no screen before).
- Shuffle chip shuffles the current feed.
- Pull down on any feed to refresh.
- Theme: System (default), Dark or Light.
- Fixed: literal backslash-n text on the About card and viewer; duplicate search chips; non-working settings (quality and Wi-Fi-only options were removed because they did nothing).
- Removed: the fake Views and Downloads counters in the viewer.

FILES OF NOTE
- app/src/main/java/com/savan/drishyam/Fx.kt — press feedback, heart state, dp helper
- app/src/main/java/com/savan/drishyam/GlowBackground.kt — animated backdrop view
- app/src/main/res/values/strings.xml — all user-facing copy (edit text here)
- app/src/main/res/values/colors.xml and values-night/colors.xml — palette for light and dark

FIREBASE / CI
- The build still expects repository secret GOOGLE_SERVICES_JSON (unchanged from 1.x).
- Do not commit google-services.json or any Cloudinary API secret.

CLOUDINARY / GALLERY — NOT YET INTEGRATED
- The About page shows "Gallery by Savan" as in development. Public gallery retrieval and developer upload are not wired to a backend yet.

NOT BUILD-TESTED IN THIS ENVIRONMENT
- No Android SDK or Gradle is available where this source was prepared. Run the GitHub Actions build and test on a real phone before release.
