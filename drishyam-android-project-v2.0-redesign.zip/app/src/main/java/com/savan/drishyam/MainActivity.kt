package com.savan.drishyam

import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.RenderEffect
import android.graphics.Shader
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.bumptech.glide.Glide

class Source(val name: String, val unsplash: Boolean, val q: String, val searchOnly: Boolean = false) {
    val items = ArrayList<Photo>()
    val ids = HashSet<String>()
    var after = ""
    var page = 1
    var done = false
    var loading = false
    var err: String? = null
}

class MainActivity : AppCompatActivity() {

    companion object {
        fun applyTheme(c: Context) {
            val mode = when (c.getSharedPreferences(PREFS_SETTINGS, Context.MODE_PRIVATE).getString("theme", "System")) {
                "Dark" -> AppCompatDelegate.MODE_NIGHT_YES
                "Light" -> AppCompatDelegate.MODE_NIGHT_NO
                else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            }
            if (AppCompatDelegate.getDefaultNightMode() != mode) AppCompatDelegate.setDefaultNightMode(mode)
        }
    }

    private lateinit var rv: RecyclerView
    private lateinit var status: TextView
    private lateinit var chips: LinearLayout
    private lateinit var chipScroll: HorizontalScrollView
    private lateinit var savedBar: View
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var segFav: TextView
    private lateinit var segBook: TextView
    private val adapter = PhotoAdapter()
    private val sources = ArrayList<Source>()
    private lateinit var cur: Source
    private var tab = 0
    private var savedMode = 0 // 0 = likes, 1 = bookmarks

    override fun onCreate(savedInstanceState: Bundle?) {
        applyTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rv = findViewById(R.id.rv)
        status = findViewById(R.id.status)
        chips = findViewById(R.id.chips)
        chipScroll = findViewById(R.id.chipScroll)
        savedBar = findViewById(R.id.savedBar)
        swipe = findViewById(R.id.swipe)
        segFav = findViewById(R.id.segFav)
        segBook = findViewById(R.id.segBook)

        swipe.setColorSchemeColors(0xFF9D7BFF.toInt(), 0xFFFF7AB6.toInt())
        swipe.setProgressBackgroundColorSchemeColor(ContextCompat.getColor(this, R.color.surface))
        swipe.setOnRefreshListener { refreshCurrent() }

        animateTitle()
        animateAbout()
        setupAbout()

        findViewById<View>(R.id.searchButton).apply { pressFx(); setOnClickListener { showSearch() } }
        findViewById<View>(R.id.settingsButton).apply { pressFx(); setOnClickListener { showSettings() } }

        if (Config.UNSPLASH_KEY.isNotBlank()) {
            for ((n, q) in listOf("Unsplash" to "wallpaper", "Nature" to "nature wallpaper", "Abstract" to "abstract wallpaper",
                "Dark" to "dark amoled wallpaper", "Minimal" to "minimal wallpaper", "City" to "city night wallpaper", "Space" to "space wallpaper"))
                sources.add(Source(n, true, q))
        }
        for (s in listOf("incredibleindia", "india_tourism", "cloud", "beach", "Earth", "river", "sky", "forest",
            "hiking", "photographs", "backpack", "mountain", "mobilephotography", "wildlifephotography"))
            sources.add(Source("r/$s", false, s))
        cur = sources[0]

        rv.layoutManager = LinearLayoutManager(this, RecyclerView.VERTICAL, false)
        rv.adapter = adapter
        rv.setHasFixedSize(true)
        rv.setItemViewCacheSize(8)
        rv.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(r: RecyclerView, dx: Int, dy: Int) {
                val lm = r.layoutManager as LinearLayoutManager
                if (dy > 0 && lm.findLastVisibleItemPosition() >= adapter.itemCount - 4) loadMore()
            }
        })

        status.setOnClickListener { if (tab == 0 && cur.err != null) { cur.err = null; loadMore() } }

        buildChips()

        listOf(R.id.n0 to 0, R.id.n1 to 1, R.id.n2 to 2).forEach { (id, n) ->
            findViewById<View>(id).apply { pressFx(); setOnClickListener { showTab(n) } }
        }
        segFav.apply { pressFx(); setOnClickListener { setSaved(0) } }
        segBook.apply { pressFx(); setOnClickListener { setSaved(1) } }

        showTab(0)
    }

    override fun onResume() {
        super.onResume()
        if (tab == 1) refreshSaved() else adapter.notifyDataSetChanged()
    }

    // ---------- About page ----------

    private fun setupAbout() {
        findViewById<ImageView>(R.id.aboutPhoto).setImageResource(R.drawable.savan)
        val blur = findViewById<ImageView>(R.id.aboutBlur)
        blur.setImageResource(R.drawable.savan)
        // Real background blur needs Android 12+; older phones keep the soft photo with the scrim.
        if (Build.VERSION.SDK_INT >= 31) {
            blur.setRenderEffect(RenderEffect.createBlurEffect(90f, 90f, Shader.TileMode.CLAMP))
        }
        findViewById<View>(R.id.ig).apply {
            pressFx()
            setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://instagram.com/savanjee"))) }
        }
    }

    private fun animateAbout() {
        val halo = findViewById<View>(R.id.aboutHalo)
        ValueAnimator.ofFloat(0.88f, 1.12f).apply {
            duration = 3200
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { a ->
                val s = a.animatedValue as Float
                halo.scaleX = s
                halo.scaleY = s
                halo.alpha = 0.5f + (s - 0.88f) * 1.2f
            }
            start()
        }
    }

    private fun animateTitle() {
        val t = findViewById<TextView>(R.id.title)
        t.post {
            val w = t.paint.measureText(t.text.toString()).coerceAtLeast(100f) * 2
            val colors = intArrayOf(0xFFFF9966.toInt(), 0xFFFF5E62.toInt(), 0xFFC04BFF.toInt(), 0xFF5B8CFF.toInt(), 0xFFFF9966.toInt())
            val sh = LinearGradient(0f, 0f, w, 0f, colors, null, Shader.TileMode.REPEAT)
            t.paint.shader = sh
            val m = Matrix()
            ValueAnimator.ofFloat(0f, w).apply {
                duration = 5000
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                addUpdateListener { m.setTranslate(it.animatedValue as Float, 0f); sh.setLocalMatrix(m); t.invalidate() }
                start()
            }
        }
    }

    // ---------- Navigation and chips ----------

    private fun showTab(n: Int) {
        tab = n
        listOf(R.id.n0, R.id.n1, R.id.n2).forEachIndexed { i, id ->
            val v = findViewById<TextView>(id)
            val on = i == n
            v.background = if (on) ContextCompat.getDrawable(this, R.drawable.accent_pill) else null
            v.setTextColor(ContextCompat.getColor(this, if (on) android.R.color.white else R.color.mute))
        }
        findViewById<View>(R.id.home).visibility = if (n < 2) View.VISIBLE else View.GONE
        findViewById<View>(R.id.about).visibility = if (n == 2) View.VISIBLE else View.GONE
        chipScroll.visibility = if (n == 0) View.VISIBLE else View.GONE
        savedBar.visibility = if (n == 1) View.VISIBLE else View.GONE
        status.visibility = if (n == 2) View.GONE else View.VISIBLE

        if (n == 1) {
            refreshSaved()
        } else {
            adapter.data = cur.items
            adapter.notifyDataSetChanged()
            updateStatus()
            if (n == 0 && cur.items.isEmpty()) loadMore()
        }
    }

    private fun buildChips() {
        chips.removeAllViews()
        for (s in sources) chips.addView(chip(s.name, s) { select(s) })
        chips.addView(chip(getString(R.string.shuffle), "shuffle") { shuffleCurrent() })
        styleChips()
    }

    private fun chip(label: String, key: Any, onTap: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 14f
        gravity = Gravity.CENTER
        setPadding(18.dp(), 0, 18.dp(), 0)
        tag = key
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, 42.dp()).apply { marginEnd = 8.dp() }
        pressFx()
        setOnClickListener { onTap() }
    }

    private fun styleChips() {
        for (i in 0 until chips.childCount) {
            val tv = chips.getChildAt(i) as TextView
            val on = tv.tag === cur
            tv.background = ContextCompat.getDrawable(this, if (on) R.drawable.accent_pill else R.drawable.glass_pill)
            tv.setTextColor(ContextCompat.getColor(this, if (on) android.R.color.white else R.color.fg))
        }
    }

    private fun select(s: Source) {
        cur = s
        styleChips()
        rv.scrollToPosition(0)
        showTab(0)
    }

    private fun shuffleCurrent() {
        if (cur.items.size < 2) return
        cur.items.shuffle()
        adapter.notifyDataSetChanged()
        rv.scrollToPosition(0)
        toast(getString(R.string.shuffled))
    }

    private fun refreshCurrent() {
        if (tab != 0 || cur.loading) { swipe.isRefreshing = false; return }
        cur.items.clear()
        cur.ids.clear()
        cur.after = ""
        cur.page = 1
        cur.done = false
        cur.err = null
        adapter.notifyDataSetChanged()
        loadMore()
    }

    // ---------- Saved (likes / bookmarks) ----------

    private fun setSaved(mode: Int) {
        savedMode = mode
        styleSeg(segFav, mode == 0)
        styleSeg(segBook, mode == 1)
        refreshSaved()
    }

    private fun styleSeg(tv: TextView, on: Boolean) {
        tv.background = ContextCompat.getDrawable(this, if (on) R.drawable.accent_pill else R.drawable.glass_pill)
        tv.setTextColor(ContextCompat.getColor(this, if (on) android.R.color.white else R.color.fg))
    }

    private fun refreshSaved() {
        adapter.data = if (savedMode == 0) Store.favs(this) else Store.bookmarks(this)
        adapter.notifyDataSetChanged()
        updateStatus()
    }

    // ---------- Settings ----------

    private fun showSettings() {
        val prefs = getSharedPreferences(PREFS_SETTINGS, Context.MODE_PRIVATE)
        val theme = prefs.getString("theme", "System")
        val haptics = hapticsOn(this)
        val options = arrayOf(
            "Theme · $theme",
            "Tap feedback · ${if (haptics) getString(R.string.haptics_on) else getString(R.string.haptics_off)}",
            "Clear image cache",
            "What’s new",
            "Credits and licences"
        )
        AlertDialog.Builder(this).setTitle(R.string.settings_title).setItems(options) { _, which ->
            when (which) {
                0 -> chooseTheme()
                1 -> {
                    prefs.edit().putBoolean("haptics", !haptics).apply()
                    toast("Tap feedback ${if (!haptics) "on" else "off"}")
                }
                2 -> {
                    Glide.get(this).clearMemory()
                    Thread {
                        Glide.get(applicationContext).clearDiskCache()
                        runOnUiThread { toast(getString(R.string.cache_cleared)) }
                    }.start()
                }
                3 -> AlertDialog.Builder(this).setTitle(R.string.whats_new_title)
                    .setMessage(R.string.whats_new_body).setPositiveButton(R.string.ok, null).show()
                4 -> AlertDialog.Builder(this).setTitle(R.string.credits_title)
                    .setMessage(R.string.credits_body).setPositiveButton(R.string.ok, null).show()
            }
        }.show()
    }

    private fun chooseTheme() {
        val prefs = getSharedPreferences(PREFS_SETTINGS, Context.MODE_PRIVATE)
        val choices = arrayOf("System", "Dark", "Light")
        val current = choices.indexOf(prefs.getString("theme", "System")).coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle(R.string.theme_title)
            .setSingleChoiceItems(choices, current) { dialog, which ->
                prefs.edit().putString("theme", choices[which]).apply()
                dialog.dismiss()
                applyTheme(this)
            }
            .setNegativeButton(R.string.cancel, null).show()
    }

    // ---------- Search ----------

    private fun showSearch() {
        val input = EditText(this).apply { hint = getString(R.string.search_hint); setSingleLine(true) }
        AlertDialog.Builder(this).setTitle(R.string.search_title).setView(input)
            .setNegativeButton(R.string.cancel, null)
            .setPositiveButton(R.string.search_action) { _, _ ->
                val q = input.text.toString().trim()
                if (q.isBlank()) { toast(getString(R.string.search_empty)); return@setPositiveButton }
                val key = q.removePrefix("r/").lowercase()
                val match = sources.firstOrNull {
                    !it.searchOnly && (it.name.removePrefix("r/").equals(key, true) || it.name.contains(q, true))
                }
                if (match != null) {
                    select(match)
                } else {
                    // Keep only the latest search chip so repeated searches never pile up.
                    sources.removeAll { it.searchOnly }
                    val search = Source("Search: $q", false, q, true)
                    sources.add(0, search)
                    buildChips()
                    select(search)
                }
            }.show()
    }

    // ---------- Feed ----------

    private fun updateStatus() {
        status.text = when {
            tab == 1 -> when {
                savedMode == 0 && Store.favs(this).isEmpty() -> getString(R.string.empty_likes)
                savedMode == 1 && Store.bookmarks(this).isEmpty() -> getString(R.string.empty_bookmarks)
                else -> ""
            }
            cur.loading -> getString(R.string.loading_more)
            cur.err != null -> cur.err + " " + getString(R.string.retry_suffix)
            cur.done -> getString(R.string.end_of_feed)
            else -> ""
        }
    }

    private fun loadMore() {
        val s = cur
        if (tab != 0 || s.loading || s.done || s.err != null) return
        s.loading = true
        updateStatus()
        Thread {
            val added = ArrayList<Photo>()
            try {
                if (s.searchOnly) {
                    val (list, last) = Api.commons(s.q, s.page)
                    s.page++
                    if (last) s.done = true
                    added.addAll(list)
                } else if (s.unsplash) {
                    val (list, last) = Api.unsplash(s.q, s.page)
                    s.page++
                    if (last) s.done = true
                    added.addAll(list)
                } else {
                    try {
                        val (list, next) = Api.reddit(s.q, s.after)
                        s.after = next
                        if (next.isEmpty()) s.done = true
                        added.addAll(list)
                        if (list.isEmpty() && next.isEmpty()) s.done = true
                    } catch (redditError: Exception) {
                        val message = redditError.message.orEmpty()
                        if (message.contains("403") || message.contains("429") || message.contains("Forbidden", true)) {
                            val (fallback, last) = Api.commons(s.q, s.page)
                            s.page++
                            if (last) s.done = true
                            added.addAll(fallback)
                        } else throw redditError
                    }
                }
            } catch (e: Exception) {
                val m = e.message ?: ""
                s.err = when {
                    m.contains("429") -> "Reddit is rate-limiting requests (HTTP 429), and the fallback source could not load."
                    m.contains("403") -> "Reddit refused the request, and the fallback source could not load. Check your connection."
                    m.contains("404") -> "This Reddit feed was not found (HTTP 404)."
                    m.contains("UnknownHost") || m.contains("timeout", true) || m.contains("Unable to resolve", true) -> "Network unavailable. Check your internet."
                    else -> "Couldn’t load photos ($m)."
                }
            }
            runOnUiThread {
                s.loading = false
                swipe.isRefreshing = false
                val fresh = added.filter { s.ids.add(it.id) }
                val start = s.items.size
                s.items.addAll(fresh)
                if (s === cur && tab == 0) {
                    adapter.notifyItemRangeInserted(start, fresh.size)
                    updateStatus()
                    rv.post { if (!rv.canScrollVertically(1)) loadMore() }
                }
            }
        }.start()
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    // ---------- Adapter ----------

    inner class PhotoAdapter : RecyclerView.Adapter<PhotoAdapter.VH>() {
        var data: List<Photo> = ArrayList()

        inner class VH(val root: View) : RecyclerView.ViewHolder(root) {
            val img: ImageView = root.findViewById(R.id.img)
            val lbl: TextView = root.findViewById(R.id.lbl)
            val heart: ImageView = root.findViewById(R.id.heart)
            init { heart.pressFx() }
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_photo, parent, false)
            v.layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                setMargins(0, 0, 0, 14.dp())
            }
            return VH(v)
        }

        override fun getItemCount() = data.size

        override fun onBindViewHolder(h: VH, pos: Int) {
            val p = data[pos]
            h.lbl.text = p.credit.ifBlank { getString(R.string.unknown_photographer) }
            h.heart.setHeart(Store.isFav(this@MainActivity, p.id))
            h.heart.contentDescription = getString(R.string.like_desc)
            val screenWidth = resources.displayMetrics.widthPixels - 28.dp()
            val ratio = if (p.width > 0 && p.height > 0) p.height.toFloat() / p.width.toFloat() else 1.18f
            h.img.layoutParams.height = (screenWidth * ratio).toInt().coerceIn(200.dp(), 650.dp())
            h.img.setBackgroundColor(p.color)
            Glide.with(h.img).load(p.thumb).centerCrop().into(h.img)
            h.heart.setOnClickListener {
                Store.toggle(this@MainActivity, p)
                if (tab == 1) refreshSaved() else h.heart.setHeart(Store.isFav(this@MainActivity, p.id))
            }
            h.root.setOnClickListener {
                startActivity(Intent(this@MainActivity, ViewerActivity::class.java).putExtra("p", p.toJson().toString()))
            }
        }
    }
}
