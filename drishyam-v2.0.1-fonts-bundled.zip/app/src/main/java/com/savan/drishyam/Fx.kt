package com.savan.drishyam

import android.content.Context
import android.content.res.ColorStateList
import android.content.res.Resources
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.animation.OvershootInterpolator
import android.widget.ImageView

const val PREFS_SETTINGS = "drishyam_settings"

fun Int.dp(): Int = (this * Resources.getSystem().displayMetrics.density).toInt()

fun hapticsOn(c: Context): Boolean =
    c.getSharedPreferences(PREFS_SETTINGS, Context.MODE_PRIVATE).getBoolean("haptics", true)

/** Press feedback: the control squishes while touched and springs back on release. */
fun View.pressFx() {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                v.animate().scaleX(0.93f).scaleY(0.93f).alpha(0.85f).setDuration(90).start()
                if (hapticsOn(v.context)) v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(220)
                    .setInterpolator(OvershootInterpolator(2.2f)).start()
        }
        false // keep click handling intact
    }
}

fun ImageView.setHeart(liked: Boolean) {
    setImageResource(if (liked) R.drawable.ic_heart_fill else R.drawable.ic_heart_outline)
    imageTintList = ColorStateList.valueOf(if (liked) 0xFFFF7AB6.toInt() else 0xFFFFFFFF.toInt())
}
