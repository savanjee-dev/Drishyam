package com.savan.drishyam

import android.app.WallpaperManager
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import org.json.JSONObject

class ViewerActivity : AppCompatActivity() {
    private lateinit var p: Photo
    private lateinit var like: TextView
    private lateinit var bookmark: TextView
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_viewer)
        p = Photo.from(JSONObject(intent.getStringExtra("p")!!))

        val iv = findViewById<ImageView>(R.id.full)
        Glide.with(this).load(p.full).thumbnail(Glide.with(this).load(p.thumb)).fitCenter().into(iv)
        iv.setOnClickListener { openFullscreen() }
        findViewById<TextView>(R.id.expand).setOnClickListener { openFullscreen() }
        findViewById<TextView>(R.id.back).setOnClickListener { finish() }
        findViewById<TextView>(R.id.shareTop).setOnClickListener { sharePhoto() }
        findViewById<TextView>(R.id.credit).text = p.credit.ifBlank { "Photographer unavailable" }
        findViewById<TextView>(R.id.published).text = p.published.takeIf { it.isNotBlank() } ?: "Publication date unavailable"
        findViewById<TextView>(R.id.camera).text = p.camera.ifBlank { "Not provided" }
        findViewById<TextView>(R.id.aperture).text = p.aperture.ifBlank { "Not provided" }
        findViewById<TextView>(R.id.focal).text = p.focalLength.ifBlank { "Not provided" }
        findViewById<TextView>(R.id.shutter).text = p.shutterSpeed.ifBlank { "Not provided" }
        findViewById<TextView>(R.id.iso).text = p.iso.ifBlank { "Not provided" }
        findViewById<TextView>(R.id.dimensions).text = if (p.width > 0 && p.height > 0) "${p.width} × ${p.height}" else "Not provided"
        findViewById<TextView>(R.id.titleDetail).text = p.title
        findViewById<TextView>(R.id.sourceLink).setOnClickListener {
            val url = p.link.ifBlank { p.full }
            if (url.isNotBlank()) startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
        like = findViewById(R.id.like)
        bookmark = findViewById(R.id.bookmark)
        refreshLike()
        refreshBookmark()
        like.setOnClickListener { Store.toggle(this, p); refreshLike() }
        bookmark.setOnClickListener { Store.toggleBookmark(this, p); refreshBookmark() }
        findViewById<TextView>(R.id.dl).setOnClickListener { fetchBitmap { saveToGallery(it) } }
        findViewById<TextView>(R.id.setwp).setOnClickListener {
            AlertDialog.Builder(this).setTitle("Set wallpaper on")
                .setItems(arrayOf("Home screen", "Lock screen", "Both")) { _, which ->
                    val flag = when (which) {
                        0 -> WallpaperManager.FLAG_SYSTEM
                        1 -> WallpaperManager.FLAG_LOCK
                        else -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
                    }
                    fetchBitmap { setWallpaper(it, flag) }
                }.show()
        }
    }

    private fun openFullscreen() {
        startActivity(Intent(this, FullscreenActivity::class.java).putExtra("p", p.toJson().toString()))
    }

    private fun sharePhoto() {
        val send = Intent(Intent.ACTION_SEND).setType("text/plain")
            .putExtra(Intent.EXTRA_TEXT, p.title + "\n" + (p.link.ifEmpty { p.full }) + "\n(via Drishyam)")
        startActivity(Intent.createChooser(send, "Share photograph"))
    }

    private fun refreshLike() {
        val liked = Store.isFav(this, p.id)
        like.text = if (liked) "♥" else "♡"
        like.contentDescription = if (liked) "Remove like" else "Like photograph"
        findViewById<TextView>(R.id.likesCount).text = "Likes\n${if (liked) 1 else 0}"
    }

    private fun refreshBookmark() {
        val saved = Store.isBookmarked(this, p.id)
        bookmark.text = if (saved) "▣" else "♧"
        bookmark.contentDescription = if (saved) "Remove bookmark" else "Bookmark photograph"
    }

    private fun fetchBitmap(done: (Bitmap) -> Unit) {
        if (busy) return
        busy = true
        toast("Preparing image…")
        if (p.dl.isNotEmpty()) Thread { Api.ping(p.dl) }.start()
        Thread {
            try {
                val bmp = Glide.with(applicationContext).asBitmap().load(p.full).submit(1440, 2960).get()
                runOnUiThread { busy = false; done(bmp) }
            } catch (e: Exception) {
                runOnUiThread { busy = false; toast("Couldn’t get the image. Check your internet.") }
            }
        }.start()
    }

    private fun setWallpaper(bmp: Bitmap, flag: Int) {
        Thread {
            try {
                WallpaperManager.getInstance(this).setBitmap(bmp, null, true, flag)
                runOnUiThread { toast("Wallpaper set ✓") }
            } catch (e: Exception) {
                runOnUiThread { toast("Couldn’t set wallpaper.") }
            }
        }.start()
    }

    private fun saveToGallery(bmp: Bitmap) {
        try {
            val v = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "Drishyam_" + System.currentTimeMillis() + ".jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Drishyam")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)!!
            contentResolver.openOutputStream(uri)!!.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            toast("Saved to Pictures/Drishyam")
        } catch (e: Exception) { toast("Couldn’t save the image.") }
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
}

class FullscreenActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fullscreen)
        val p = Photo.from(JSONObject(intent.getStringExtra("p")!!))
        val image = findViewById<ImageView>(R.id.fullscreenImage)
        Glide.with(this).load(p.full).thumbnail(Glide.with(this).load(p.thumb)).fitCenter().into(image)
        findViewById<View>(R.id.closeFullscreen).setOnClickListener { finish() }
        image.setOnClickListener {
            val close = findViewById<View>(R.id.closeFullscreen)
            close.visibility = if (close.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        }
    }
}
