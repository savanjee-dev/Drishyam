package com.savan.drishyam

import android.content.Context
import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Config {
    // Paste your Unsplash Access Key between the quotes to turn on the Unsplash tabs.
    const val UNSPLASH_KEY = ""
    const val UA = "Drishyam/1.0 (Android wallpaper app by Savan)"
}

data class Photo(
    val id: String, val thumb: String, val full: String, val title: String,
    val credit: String, val link: String, val dl: String, val color: Int
) {
    fun toJson(): JSONObject = JSONObject().put("id", id).put("thumb", thumb).put("full", full)
        .put("title", title).put("credit", credit).put("link", link).put("dl", dl).put("color", color)

    companion object {
        fun from(o: JSONObject) = Photo(
            o.getString("id"), o.getString("thumb"), o.getString("full"), o.optString("title"),
            o.optString("credit"), o.optString("link"), o.optString("dl"), o.optInt("color", 0xFF222222.toInt())
        )
    }
}

object Store {
    private var cache: MutableList<Photo>? = null
    private fun prefs(c: Context) = c.getSharedPreferences("drishyam", 0)
    fun favs(c: Context): MutableList<Photo> {
        cache?.let { return it }
        val list = ArrayList<Photo>()
        try {
            val a = JSONArray(prefs(c).getString("favs", "[]"))
            for (i in 0 until a.length()) list.add(Photo.from(a.getJSONObject(i)))
        } catch (e: Exception) { }
        cache = list
        return list
    }
    fun isFav(c: Context, id: String) = favs(c).any { it.id == id }
    fun toggle(c: Context, p: Photo): Boolean {
        val l = favs(c)
        val had = l.removeAll { it.id == p.id }
        if (!had) l.add(p)
        val arr = JSONArray()
        l.forEach { arr.put(it.toJson()) }
        prefs(c).edit().putString("favs", arr.toString()).apply()
        return !had
    }
}

object Api {
    private fun get(url: String, headers: Map<String, String>): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 20000
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        if (c.responseCode != 200) throw Exception("HTTP " + c.responseCode)
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    fun ping(url: String) {
        try { get(url, mapOf("Authorization" to "Client-ID " + Config.UNSPLASH_KEY)) } catch (e: Exception) { }
    }

    /** Returns photos and the "after" token ("" when there is no more). */
    fun reddit(sub: String, after: String): Pair<List<Photo>, String> {
        val url = "https://www.reddit.com/r/$sub/hot.json?limit=30&raw_json=1" + if (after.isNotEmpty()) "&after=$after" else ""
        val data = JSONObject(get(url, mapOf("User-Agent" to Config.UA))).getJSONObject("data")
        var next = data.optString("after", "")
        if (next == "null") next = ""
        val out = ArrayList<Photo>()
        val kids = data.getJSONArray("children")
        for (i in 0 until kids.length()) {
            val d = kids.getJSONObject(i).optJSONObject("data") ?: continue
            if (d.optBoolean("over_18") || d.optBoolean("stickied")) continue
            val u = d.optString("url_overridden_by_dest", d.optString("url", ""))
            val isImg = d.optString("post_hint") == "image" || Regex("\\.(jpe?g|png|webp)(\\?|$)", RegexOption.IGNORE_CASE).containsMatchIn(u)
            if (!isImg || !u.startsWith("https://")) continue
            var thumb = u
            val res = d.optJSONObject("preview")?.optJSONArray("images")?.optJSONObject(0)?.optJSONArray("resolutions")
            if (res != null && res.length() > 0) {
                var pick = res.getJSONObject(res.length() - 1)
                for (k in 0 until res.length()) {
                    val r = res.getJSONObject(k)
                    if (r.optInt("width") >= 320) { pick = r; break }
                }
                thumb = pick.optString("url", u)
            }
            val sr = d.optString("subreddit")
            out.add(Photo(d.getString("name"), thumb, u, d.optString("title"), "r/$sr",
                "https://redd.it/" + d.optString("id"), "", 0xFF222222.toInt()))
        }
        return Pair(out, next)
    }

    /** Returns photos and whether this was the last page. */
    fun unsplash(query: String, page: Int): Pair<List<Photo>, Boolean> {
        val url = "https://api.unsplash.com/search/photos?query=" + java.net.URLEncoder.encode(query, "UTF-8") +
            "&orientation=portrait&per_page=20&page=$page"
        val j = JSONObject(get(url, mapOf("Authorization" to "Client-ID " + Config.UNSPLASH_KEY, "Accept-Version" to "v1")))
        val arr = j.getJSONArray("results")
        val out = ArrayList<Photo>()
        for (i in 0 until arr.length()) {
            val p = arr.getJSONObject(i)
            val urls = p.getJSONObject("urls")
            val raw = urls.getString("raw")
            val full = raw + (if (raw.contains("?")) "&" else "?") + "w=1440&q=85&fm=jpg&fit=max"
            val user = p.getJSONObject("user")
            val col = try { Color.parseColor(p.optString("color", "#222222")) } catch (e: Exception) { 0xFF222222.toInt() }
            out.add(Photo(p.getString("id"), urls.getString("small"), full,
                p.optString("alt_description", "Photo").let { if (it == "null") "Photo" else it },
                "📷 " + user.optString("name"),
                p.getJSONObject("links").optString("html") + "?utm_source=drishyam&utm_medium=referral",
                p.getJSONObject("links").optString("download_location"), col))
        }
        return Pair(out, page >= j.optInt("total_pages", 1) || arr.length() == 0)
    }
}
