Drishyam by Savan - Android project.
Build: upload all files to a GitHub repository, open the Actions tab, run "Build APK",
then download "Drishyam-APK" from the finished run.
To enable Unsplash: put your Access Key in app/src/main/java/com/savan/drishyam/Data.kt (UNSPLASH_KEY).
Fonts: Erica One and Nothing You Could Do (SIL Open Font License, see LICENSES).
