package com.savan.drishyam

import android.app.WallpaperManager
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.MediaStore
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import org.json.JSONObject

class ViewerActivity : AppCompatActivity() {
    private lateinit var p: Photo
    private lateinit var like: TextView
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_viewer)
        p = Photo.from(JSONObject(intent.getStringExtra("p")!!))

        val iv = findViewById<ImageView>(R.id.full)
        Glide.with(this).load(p.full).thumbnail(Glide.with(this).load(p.thumb)).into(iv)

        findViewById<TextView>(R.id.credit).text = p.credit
        findViewById<TextView>(R.id.back).setOnClickListener { finish() }
        like = findViewById(R.id.like)
        refreshLike()
        like.setOnClickListener { Store.toggle(this, p); refreshLike() }
        findViewById<TextView>(R.id.share).setOnClickListener {
            val send = Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, p.title + "\n" + (if (p.link.isNotEmpty()) p.link else p.full) + "\n(via Drishyam)")
            startActivity(Intent.createChooser(send, "Share"))
        }
        findViewById<TextView>(R.id.dl).setOnClickListener { fetchBitmap { saveToGallery(it) } }
        findViewById<TextView>(R.id.setwp).setOnClickListener {
            AlertDialog.Builder(this).setTitle("Set wallpaper on")
                .setItems(arrayOf("Home screen", "Lock screen", "Both")) { _, which ->
                    val flag = when (which) {
                        0 -> WallpaperManager.FLAG_SYSTEM
                        1 -> WallpaperManager.FLAG_LOCK
                        else -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
                    }
                    fetchBitmap { setWallpaper(it, flag) }
                }.show()
        }
    }

    private fun refreshLike() {
        like.text = if (Store.isFav(this, p.id)) "♥ Liked" else "♡ Like"
    }

    private fun fetchBitmap(done: (Bitmap) -> Unit) {
        if (busy) return
        busy = true
        toast("Preparing image…")
        if (p.dl.isNotEmpty()) Thread { Api.ping(p.dl) }.start()
        Thread {
            try {
                val bmp = Glide.with(applicationContext).asBitmap().load(p.full).submit(1440, 2960).get()
                runOnUiThread { busy = false; done(bmp) }
            } catch (e: Exception) {
                runOnUiThread { busy = false; toast("Couldn’t get the image. Check your internet.") }
            }
        }.start()
    }

    private fun setWallpaper(bmp: Bitmap, flag: Int) {
        Thread {
            try {
                WallpaperManager.getInstance(this).setBitmap(bmp, null, true, flag)
                runOnUiThread { toast("Wallpaper set ✓") }
            } catch (e: Exception) {
                runOnUiThread { toast("Couldn’t set wallpaper.") }
            }
        }.start()
    }

    private fun saveToGallery(bmp: Bitmap) {
        try {
            val v = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "Drishyam_" + System.currentTimeMillis() + ".jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Drishyam")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)!!
            contentResolver.openOutputStream(uri)!!.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            toast("Saved to Pictures/Drishyam")
        } catch (e: Exception) {
            toast("Couldn’t save the image.")
        }
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
}
