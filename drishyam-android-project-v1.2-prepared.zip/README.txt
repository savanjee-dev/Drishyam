Drishyam Android project

Package: com.savan.drishyam
Version: 1.2 (versionCode 2)

Firebase build configuration
- GitHub Actions expects a repository Actions secret named GOOGLE_SERVICES_JSON.
- The workflow writes that secret to app/google-services.json only during the build.
- Do not commit google-services.json or any Cloudinary API secret to this public repository.
- Firebase Authentication SDK is included, but developer-only gallery authentication flows and backend authorisation are not yet implemented.

Current homepage source priority:
1. r/incredibleindia
2. r/India_tourism
3. r/cloud
4. r/beach
5. r/Earth
6. r/river
7. r/sky
8. r/forest

Important: This source package has not been build-tested in this environment because a Gradle executable / Android SDK is not available here. Run GitHub Actions and inspect the build result before installing the APK.

Not yet implemented in this source package:
- Cloudinary signed-upload backend and secure developer-only gallery management
- Remote update feed / release notes backend
- Settings UI and persisted dark/light, Wi-Fi-only download, and cache-management controls
- Homepage search UI
- Full feed and image-quality runtime verification
