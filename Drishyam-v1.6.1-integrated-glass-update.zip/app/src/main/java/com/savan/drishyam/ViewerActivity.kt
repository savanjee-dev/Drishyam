package com.savan.drishyam

import android.app.WallpaperManager
import android.app.Dialog
import android.graphics.Typeface
import android.view.Gravity
import android.view.WindowManager
import android.content.res.Resources
import android.widget.LinearLayout
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import org.json.JSONObject

class ViewerActivity : AppCompatActivity() {
    private lateinit var p: Photo
    private lateinit var like: TextView
    private lateinit var bookmark: TextView
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_viewer)
        // Guard the activity boundary: malformed or missing photo payloads must not crash the app.
        val payload = intent.getStringExtra("p")
        p = try {
            if (payload.isNullOrBlank()) throw IllegalArgumentException("Missing photo data")
            Photo.from(JSONObject(payload))
        } catch (_: Exception) {
            Toast.makeText(this, "Couldn't open this photo. Please try another image.", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        val iv = findViewById<ImageView>(R.id.full)
        Glide.with(this).load(p.full).thumbnail(Glide.with(this).load(p.thumb)).fitCenter().into(iv)
        iv.setOnClickListener { openFullscreen() }
        findViewById<TextView>(R.id.expand).setOnClickListener { openFullscreen() }
        findViewById<TextView>(R.id.back).setOnClickListener { finish() }
        findViewById<TextView>(R.id.shareTop).setOnClickListener { sharePhoto() }
        findViewById<TextView>(R.id.credit).text = p.credit.ifBlank { "Photographer unavailable" }
        findViewById<TextView>(R.id.published).text = p.published.takeIf { it.isNotBlank() } ?: "Publication date unavailable"
        findViewById<TextView>(R.id.camera).text = p.camera.ifBlank { "Not provided" }
        findViewById<TextView>(R.id.aperture).text = p.aperture.ifBlank { "Not provided" }
        findViewById<TextView>(R.id.focal).text = p.focalLength.ifBlank { "Not provided" }
        findViewById<TextView>(R.id.shutter).text = p.shutterSpeed.ifBlank { "Not provided" }
        findViewById<TextView>(R.id.iso).text = p.iso.ifBlank { "Not provided" }
        findViewById<TextView>(R.id.dimensions).text = if (p.width > 0 && p.height > 0) "${p.width} × ${p.height}" else "Not provided"
        findViewById<TextView>(R.id.titleDetail).text = p.title
        findViewById<TextView>(R.id.sourceLink).setOnClickListener {
            val url = p.link.ifBlank { p.full }
            if (url.isNotBlank()) startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
        like = findViewById(R.id.like)
        bookmark = findViewById(R.id.bookmark)
        refreshLike()
        refreshBookmark()
        like.setOnClickListener { Store.toggle(this, p); refreshLike() }
        bookmark.setOnClickListener { Store.toggleBookmark(this, p); refreshBookmark() }
        findViewById<TextView>(R.id.dl).setOnClickListener { fetchBitmap(forWallpaper = false) { saveToGallery(it) } }
        findViewById<TextView>(R.id.setwp).setOnClickListener {
            showWallpaperOptions()
        }
    }


    private fun showWallpaperOptions() {
        val dialog = Dialog(this)
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(22.dp(), 20.dp(), 22.dp(), 18.dp())
            background = getDrawable(R.drawable.dialog_glass)
        }
        panel.addView(TextView(this).apply {
            text = "Set wallpaper on"; textSize = 22f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFFFF8FF.toInt()); setPadding(2.dp(), 0, 0, 14.dp())
        })
        fun action(label: String, flag: Int) {
            panel.addView(TextView(this).apply {
                text = label; gravity = Gravity.CENTER; textSize = 15f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(0xFFFFF8FF.toInt()); background = getDrawable(R.drawable.pill_glass)
                setPadding(16.dp(), 14.dp(), 16.dp(), 14.dp()); isClickable = true; isFocusable = true
                setOnClickListener { dialog.dismiss(); fetchBitmap(forWallpaper = true) { setWallpaper(it, flag) } }
            }, LinearLayout.LayoutParams(-1, 50.dp()).apply { bottomMargin = 9.dp() })
        }
        action("Home screen", WallpaperManager.FLAG_SYSTEM)
        action("Lock screen", WallpaperManager.FLAG_LOCK)
        action("Both screens", WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK)
        panel.addView(TextView(this).apply {
            text = "Cancel"; gravity = Gravity.CENTER; textSize = 14f; setTextColor(0xFFB7ACBE.toInt())
            setPadding(12.dp(), 10.dp(), 12.dp(), 10.dp()); isClickable = true; setOnClickListener { dialog.dismiss() }
        }, LinearLayout.LayoutParams(-1, 42.dp()))
        dialog.setContentView(panel)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setDimAmount(0.7f)
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels - 28.dp()).coerceAtLeast(280.dp()), WindowManager.LayoutParams.WRAP_CONTENT)
        dialog.window?.setGravity(Gravity.BOTTOM)
    }

    private fun openFullscreen() {
        startActivity(Intent(this, FullscreenActivity::class.java).putExtra("p", p.toJson().toString()))
    }

    private fun sharePhoto() {
        val send = Intent(Intent.ACTION_SEND).setType("text/plain")
            .putExtra(Intent.EXTRA_TEXT, p.title + "\n" + (p.link.ifEmpty { p.full }) + "\n(via Drishyam)")
        startActivity(Intent.createChooser(send, "Share photograph"))
    }

    private fun refreshLike() {
        val liked = Store.isFav(this, p.id)
        like.text = if (liked) "♥" else "♡"
        like.contentDescription = if (liked) "Remove like" else "Like photograph"
        findViewById<TextView>(R.id.likesCount).text = "Likes\n${if (liked) 1 else 0}"
    }

    private fun refreshBookmark() {
        val saved = Store.isBookmarked(this, p.id)
        bookmark.text = if (saved) "▣" else "♧"
        bookmark.contentDescription = if (saved) "Remove bookmark" else "Bookmark photograph"
    }

    private fun fetchBitmap(forWallpaper: Boolean, done: (Bitmap) -> Unit) {
        if (busy) return
        val prefs = getSharedPreferences("drishyam_settings", MODE_PRIVATE)
        if (!forWallpaper && prefs.getBoolean("wifi_only", false)) {
            val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
            val network = cm.activeNetwork
            val caps = network?.let { cm.getNetworkCapabilities(it) }
            if (caps == null || !caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                toast("Wi-Fi-only downloads is enabled. Connect to Wi-Fi first.")
                return
            }
        }
        busy = true
        toast(if (forWallpaper) "Preparing wallpaper…" else "Preparing download…")
        if (p.dl.isNotEmpty() && !forWallpaper) Thread { Api.ping(p.dl) }.start()
        val quality = if (forWallpaper) prefs.getString("wallpaper_quality", "Best available") else prefs.getString("download_quality", "High")
        val (maxW, maxH) = when {
            forWallpaper && quality == "Screen resolution" -> {
                val dm = resources.displayMetrics
                Pair(dm.widthPixels.coerceAtLeast(720), dm.heightPixels.coerceAtLeast(1280))
            }
            !forWallpaper && quality == "Standard" -> Pair(1080, 1920)
            forWallpaper && quality == "Best available" -> Pair(p.width.coerceAtLeast(4096), p.height.coerceAtLeast(4096))
            !forWallpaper && quality == "Original" -> Pair(p.width.coerceAtLeast(4096), p.height.coerceAtLeast(4096))
            else -> Pair(2400, 4800)
        }
        Thread {
            try {
                val bmp = Glide.with(applicationContext).asBitmap().load(p.full).submit(maxW, maxH).get()
                runOnUiThread { busy = false; done(bmp) }
            } catch (e: Exception) {
                runOnUiThread { busy = false; toast("Couldn’t get the image. Check your internet.") }
            }
        }.start()
    }

    private fun setWallpaper(bmp: Bitmap, flag: Int) {
        Thread {
            try {
                WallpaperManager.getInstance(this).setBitmap(bmp, null, true, flag)
                runOnUiThread { toast("Wallpaper set ✓") }
            } catch (e: Exception) {
                runOnUiThread { toast("Couldn’t set wallpaper: ${e.message ?: "system error"}") }
            }
        }.start()
    }

    private fun saveToGallery(bmp: Bitmap) {
        try {
            val v = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "Drishyam_" + System.currentTimeMillis() + ".jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Drishyam")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)!!
            val stream = contentResolver.openOutputStream(uri) ?: throw IllegalStateException("Unable to open destination")
            val ok = stream.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            if (!ok) { contentResolver.delete(uri, null, null); throw IllegalStateException("Image encoding failed") }
            toast("Saved to Pictures/Drishyam")
        } catch (e: Exception) { toast("Couldn’t save image: ${e.message ?: "storage error"}") }
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
}

class FullscreenActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fullscreen)
        val payload = intent.getStringExtra("p")
        val p = try {
            if (payload.isNullOrBlank()) throw IllegalArgumentException("Missing photo data")
            Photo.from(JSONObject(payload))
        } catch (_: Exception) {
            Toast.makeText(this, "Couldn't open this photo in full screen.", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        val image = findViewById<ImageView>(R.id.fullscreenImage)
        Glide.with(this).load(p.full).thumbnail(Glide.with(this).load(p.thumb)).fitCenter().into(image)
        findViewById<View>(R.id.closeFullscreen).setOnClickListener { finish() }
        image.setOnClickListener {
            val close = findViewById<View>(R.id.closeFullscreen)
            close.visibility = if (close.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        }
    }
}
