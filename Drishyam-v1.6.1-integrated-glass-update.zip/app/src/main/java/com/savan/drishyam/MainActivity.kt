package com.savan.drishyam

import android.animation.ValueAnimator
import android.content.Intent
import android.app.AlertDialog
import android.app.Dialog
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.WindowManager
import android.widget.ScrollView
import android.widget.EditText
import android.widget.Button
import android.graphics.drawable.GradientDrawable
import android.content.res.Resources
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Shader
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.material.card.MaterialCardView

fun Int.dp(): Int = (this * Resources.getSystem().displayMetrics.density).toInt()

class Source(val name: String, val unsplash: Boolean, val q: String, val searchOnly: Boolean = false) {
    val items = ArrayList<Photo>()
    val ids = HashSet<String>()
    var after = ""
    var page = 1
    var done = false
    var loading = false
    var err: String? = null
}

class MainActivity : AppCompatActivity() {
    private lateinit var rv: RecyclerView
    private lateinit var status: TextView
    private lateinit var chips: LinearLayout
    private lateinit var chipScroll: View
    private val adapter = PhotoAdapter()
    private val sources = ArrayList<Source>()
    private lateinit var cur: Source
    private var tab = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        rv = findViewById(R.id.rv)
        status = findViewById(R.id.status)
        chips = findViewById(R.id.chips)
        chipScroll = findViewById(R.id.chipScroll)

        animateTitle()
        findViewById<View>(R.id.searchButton).setOnClickListener { animateTap(it); showSearch() }
        findViewById<View>(R.id.settingsButton).setOnClickListener { animateTap(it); showSettings() }
        animateAboutCard()

        if (Config.UNSPLASH_KEY.isNotBlank()) {
            for ((n, q) in listOf("Unsplash" to "wallpaper", "Nature" to "nature wallpaper", "Abstract" to "abstract wallpaper",
                "Dark" to "dark amoled wallpaper", "Minimal" to "minimal wallpaper", "City" to "city night wallpaper", "Space" to "space wallpaper"))
                sources.add(Source(n, true, q))
        }
        for (s in listOf("incredibleindia", "india_tourism", "cloud", "beach", "Earth", "river", "sky", "forest",
            "hiking", "photographs", "backpack", "mountain", "mobilephotography", "wildlifephotography"))
            sources.add(Source("r/$s", false, s))
        cur = sources[0]

        rv.layoutManager = LinearLayoutManager(this, RecyclerView.VERTICAL, false)
        rv.adapter = adapter
        rv.setHasFixedSize(true)
        rv.setItemViewCacheSize(8)
        rv.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(r: RecyclerView, dx: Int, dy: Int) {
                val lm = r.layoutManager as LinearLayoutManager
                if (dy > 0 && lm.findLastVisibleItemPosition() >= adapter.itemCount - 4) loadMore()
            }
        })
        status.setOnClickListener { if (tab == 0 && cur.err != null) { cur.err = null; loadMore() } }

        buildChips()
        findViewById<View>(R.id.n0).setOnClickListener { showTab(0) }
        findViewById<View>(R.id.n1).setOnClickListener { showTab(1) }
        findViewById<View>(R.id.n2).setOnClickListener { showTab(2) }
        findViewById<View>(R.id.ig).setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://instagram.com/savanjee")))
        }
        showTab(0)
    }

    override fun onResume() {
        super.onResume()
        if (tab == 1) { adapter.data = Store.favs(this); adapter.notifyDataSetChanged(); updateStatus() }
        else adapter.notifyDataSetChanged()
    }

    private fun animateTap(view: View) {
        view.animate().cancel()
        view.scaleX = 1f; view.scaleY = 1f
        view.animate().scaleX(0.93f).scaleY(0.93f).setDuration(85).withEndAction {
            view.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
        }.start()
    }

    private fun glassDialog(title: String): Pair<Dialog, LinearLayout> {
        val dialog = Dialog(this)
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22.dp(), 20.dp(), 22.dp(), 18.dp())
            background = getDrawable(R.drawable.dialog_glass)
        }
        val heading = TextView(this).apply {
            text = title; textSize = 22f; setTextColor(getColor(R.color.fg)); typeface = Typeface.DEFAULT_BOLD
            setPadding(2.dp(), 0, 2.dp(), 14.dp())
        }
        outer.addView(heading)
        dialog.setContentView(outer)
        dialog.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setDimAmount(0.68f)
            addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) setBackgroundBlurRadius(28)
        }
        dialog.setOnShowListener {
            dialog.window?.setLayout((resources.displayMetrics.widthPixels - 28.dp()).coerceAtLeast(280.dp()), WindowManager.LayoutParams.WRAP_CONTENT)
            dialog.window?.setGravity(Gravity.BOTTOM)
            dialog.window?.attributes = dialog.window?.attributes?.apply { y = 14.dp() }
        }
        return dialog to outer
    }

    private fun pillAction(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label; gravity = Gravity.CENTER; textSize = 14f; typeface = Typeface.DEFAULT_BOLD
        setTextColor(getColor(R.color.fg)); background = getDrawable(R.drawable.pill_glass)
        setPadding(18.dp(), 12.dp(), 18.dp(), 12.dp())
        isClickable = true; isFocusable = true
        setOnClickListener { onClick() }
    }

    private fun showSearch() {
        val (dialog, panel) = glassDialog("Search Drishyam")
        val input = EditText(this).apply {
            hint = "Photos, places or subreddit…"; setSingleLine(true); textSize = 16f
            setTextColor(getColor(R.color.fg)); setHintTextColor(getColor(R.color.mute))
            background = getDrawable(R.drawable.pill_dark); setPadding(16.dp(), 12.dp(), 16.dp(), 12.dp())
        }
        panel.addView(input, LinearLayout.LayoutParams(-1, 52.dp()))
        val helper = TextView(this).apply {
            text = "Try: r/incredibleindia · mountains · beaches"; textSize = 12f
            setTextColor(getColor(R.color.mute)); setPadding(4.dp(), 10.dp(), 4.dp(), 14.dp())
        }
        panel.addView(helper)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END; setPadding(0, 4.dp(), 0, 0) }
        actions.addView(pillAction("Cancel") { dialog.dismiss() }, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = 8.dp() })
        actions.addView(pillAction("Search  ↗") {
            val q = input.text.toString().trim()
            if (q.isBlank()) { input.error = "Enter a photo topic or subreddit"; return@pillAction }
            val key = q.removePrefix("r/").lowercase()
            val match = sources.firstOrNull { it.name.removePrefix("r/").equals(key, true) || it.name.contains(q, true) }
            if (match != null) {
                select(match); status.text = "Showing ${match.name}"
            } else {
                val search = Source("Search: $q", false, q, true)
                sources.add(0, search); buildChips(); select(search); chipScroll.visibility = View.VISIBLE
                status.text = "Searching public Wikimedia photo results…"
            }
            dialog.dismiss()
        }, LinearLayout.LayoutParams(-2, -2))
        panel.addView(actions)
        dialog.show()
    }

    private fun showSettings() {
        val (dialog, panel) = glassDialog("Settings & appearance")
        val subtitle = TextView(this).apply {
            text = "Make Drishyam feel like yours"; textSize = 13f; setTextColor(getColor(R.color.mute))
            setPadding(2.dp(), 0, 2.dp(), 14.dp())
        }
        panel.addView(subtitle)
        val prefs = getSharedPreferences("drishyam_settings", MODE_PRIVATE)
        fun row(title: String, detail: String, action: () -> Unit) {
            val wrap = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; background = getDrawable(R.drawable.pill_dark)
                setPadding(16.dp(), 13.dp(), 16.dp(), 13.dp()); isClickable = true; isFocusable = true
                setOnClickListener { action() }
            }
            wrap.addView(TextView(this).apply { text = title; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(getColor(R.color.fg)) })
            wrap.addView(TextView(this).apply { text = detail; textSize = 12f; setTextColor(getColor(R.color.mute)); setPadding(0, 4.dp(), 0, 0) })
            panel.addView(wrap, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8.dp() })
        }
        row("Appearance", if (prefs.getBoolean("light", false)) "Light theme · tap to switch" else "Dark theme · tap to switch") {
            val light = !prefs.getBoolean("light", false); prefs.edit().putBoolean("light", light).apply()
            AppCompatDelegate.setDefaultNightMode(if (light) AppCompatDelegate.MODE_NIGHT_NO else AppCompatDelegate.MODE_NIGHT_YES)
            dialog.dismiss(); toast("${if (light) "Light" else "Dark"} theme selected")
        }
        row("Streaming quality", prefs.getString("stream_quality", "Auto") ?: "Auto") { chooseSetting("Streaming quality", arrayOf("Auto", "Standard", "High"), "stream_quality", dialog) }
        row("Download quality", prefs.getString("download_quality", "High") ?: "High") { chooseSetting("Download quality", arrayOf("Standard", "High", "Original"), "download_quality", dialog) }
        row("Wallpaper quality", prefs.getString("wallpaper_quality", "Best available") ?: "Best available") { chooseSetting("Wallpaper quality", arrayOf("Screen resolution", "Best available"), "wallpaper_quality", dialog) }
        row("Wi-Fi-only downloads", if (prefs.getBoolean("wifi_only", false)) "Enabled · tap to disable" else "Disabled · tap to enable") {
            val on = !prefs.getBoolean("wifi_only", false); prefs.edit().putBoolean("wifi_only", on).apply()
            dialog.dismiss(); toast("Wi-Fi-only downloads ${if (on) "enabled" else "disabled"}"); showSettings()
        }
        row("Clear image cache", "Free cached image storage") {
            Glide.get(this).clearMemory(); Thread { Glide.get(applicationContext).clearDiskCache(); runOnUiThread { toast("Image cache cleared") } }.start(); dialog.dismiss()
        }
        row("What's New · v1.6", "Release notes and update information") {
            dialog.dismiss(); showWhatsNew()
        }
        panel.addView(pillAction("Done") { dialog.dismiss() }, LinearLayout.LayoutParams(-1, 48.dp()).apply { topMargin = 2.dp() })
        dialog.show()
    }

    private fun chooseSetting(title: String, choices: Array<String>, key: String, parent: Dialog? = null) {
        parent?.dismiss()
        val (dialog, panel) = glassDialog(title)
        val prefs = getSharedPreferences("drishyam_settings", MODE_PRIVATE)
        val current = prefs.getString(key, if (key == "download_quality") "High" else if (key == "wallpaper_quality") "Best available" else choices[0])
        choices.forEach { choice ->
            val selected = choice == current
            val row = pillAction((if (selected) "✓   " else "     ") + choice) {
                prefs.edit().putString(key, choice).apply(); dialog.dismiss(); toast("$title saved: $choice"); showSettings()
            }
            row.gravity = Gravity.START or Gravity.CENTER_VERTICAL
            panel.addView(row, LinearLayout.LayoutParams(-1, 48.dp()).apply { bottomMargin = 8.dp() })
        }
        panel.addView(pillAction("Cancel") { dialog.dismiss(); showSettings() }, LinearLayout.LayoutParams(-1, 44.dp()))
        dialog.show()
    }

    private fun showWhatsNew() {
        val (dialog, panel) = glassDialog("What's New · v1.6")
        val body = TextView(this).apply {
            text = "• Glass-style pill controls and updated dialogs\n• Photo and subreddit search\n• Theme, streaming, download and wallpaper quality preferences\n• Wi-Fi-only download preference and cache clearing\n• Improved photo details, saved images and wallpaper actions\n\nUpdates are announced here. Installing a newer version still requires a new APK."
            textSize = 14f; setTextColor(getColor(R.color.fg)); setLineSpacing(5.dp().toFloat(), 1f); setPadding(2.dp(), 0, 2.dp(), 18.dp())
        }
        panel.addView(body)
        panel.addView(pillAction("Check for updates  ↗") {
            dialog.dismiss()
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/savanjee-dev/Drishyam/releases")))
        }, LinearLayout.LayoutParams(-1, 46.dp()).apply { bottomMargin = 8.dp() })
        panel.addView(pillAction("Got it") { dialog.dismiss() }, LinearLayout.LayoutParams(-1, 44.dp()))
        dialog.show()
    }

    private fun animateAboutCard() {
        val hero = findViewById<View>(R.id.aboutHero) ?: return
        val colors = arrayOf(intArrayOf(0xFFFF9966.toInt(), 0xFFFF5E62.toInt(), 0xFF5B2A9E.toInt()), intArrayOf(0xFF5B8CFF.toInt(), 0xFFB84DFF.toInt(), 0xFFFF9966.toInt()), intArrayOf(0xFF20C997.toInt(), 0xFF4361EE.toInt(), 0xFFB5179E.toInt()))
        android.animation.ValueAnimator.ofInt(0, 2).apply {
            duration = 9000; repeatCount = android.animation.ValueAnimator.INFINITE; repeatMode = android.animation.ValueAnimator.REVERSE
            addUpdateListener { a ->
                val c = colors[(a.animatedValue as Int).coerceIn(0, 2)]
                hero.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, c).apply { cornerRadius = 28.dp().toFloat() }
            }
            start()
        }
    }

    private fun toast(message: String) = android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_SHORT).show()

    private fun animateTitle() {
        val t = findViewById<TextView>(R.id.title)
        t.post {
            val w = t.paint.measureText(t.text.toString()).coerceAtLeast(100f) * 2
            val colors = intArrayOf(0xFFFF9966.toInt(), 0xFFFF5E62.toInt(), 0xFFC04BFF.toInt(), 0xFF5B8CFF.toInt(), 0xFFFF9966.toInt())
            val sh = LinearGradient(0f, 0f, w, 0f, colors, null, Shader.TileMode.REPEAT)
            t.paint.shader = sh
            val m = Matrix()
            ValueAnimator.ofFloat(0f, w).apply {
                duration = 5000
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                addUpdateListener { m.setTranslate(it.animatedValue as Float, 0f); sh.setLocalMatrix(m); t.invalidate() }
                start()
            }
        }
    }

    private fun buildChips() {
        chips.removeAllViews()
        for (s in sources) {
            val tv = TextView(this)
            tv.text = s.name
            tv.textSize = 14f
            tv.setPadding(18.dp(), 0, 18.dp(), 0)
            tv.gravity = android.view.Gravity.CENTER
            tv.tag = s
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, 40.dp())
            lp.marginEnd = 8.dp()
            tv.layoutParams = lp
            tv.setOnClickListener { select(s) }
            chips.addView(tv)
        }
        styleChips()
    }

    private fun styleChips() {
        for (i in 0 until chips.childCount) {
            val tv = chips.getChildAt(i) as TextView
            val on = tv.tag === cur
            tv.setBackgroundResource(if (on) R.drawable.pill_fg else R.drawable.pill_chip)
            tv.setTextColor(getColor(if (on) R.color.bg else R.color.fg))
        }
    }

    private fun select(s: Source) {
        cur = s
        tab = 0
        styleChips()
        adapter.data = s.items
        adapter.notifyDataSetChanged()
        rv.scrollToPosition(0)
        updateStatus()
        if (s.items.isEmpty()) loadMore()
    }

    private fun showTab(n: Int) {
        tab = n
        val ids = intArrayOf(R.id.n0, R.id.n1, R.id.n2)
        for (i in 0..2) {
            val v = findViewById<TextView>(ids[i])
            v.setBackgroundResource(if (i == n) R.drawable.pill_accent else 0)
            v.setTextColor(if (i == n) 0xFFFFFFFF.toInt() else getColor(R.color.mute))
        }
        findViewById<View>(R.id.home).visibility = if (n < 2) View.VISIBLE else View.GONE
        findViewById<View>(R.id.about).visibility = if (n == 2) View.VISIBLE else View.GONE
        chipScroll.visibility = if (n == 0) View.VISIBLE else View.GONE
        if (n == 1) adapter.data = Store.favs(this) else if (n == 0) adapter.data = cur.items
        adapter.notifyDataSetChanged()
        updateStatus()
        if (n == 0 && cur.items.isEmpty()) loadMore()
    }

    private fun updateStatus() {
        status.text = when {
            tab == 1 -> if (Store.favs(this).isEmpty()) "Nothing saved yet. Tap ♡ on a wallpaper." else ""
            cur.loading -> "Loading more…"
            cur.err != null -> cur.err + " Tap to retry."
            cur.done -> "You’ve reached the end"
            else -> ""
        }
    }

    private fun loadMore() {
        val s = cur
        if (tab != 0 || s.loading || s.done || s.err != null) return
        s.loading = true
        updateStatus()
        Thread {
            var added = ArrayList<Photo>()
            try {
                if (s.searchOnly) {
                    val (list, last) = Api.commons(s.q, s.page)
                    s.page++
                    if (last) s.done = true
                    added.addAll(list)
                } else if (s.unsplash) {
                    val (list, last) = Api.unsplash(s.q, s.page)
                    s.page++
                    if (last) s.done = true
                    added.addAll(list)
                } else {
                    try {
                        val (list, next) = Api.reddit(s.q, s.after)
                        s.after = next
                        if (next.isEmpty()) s.done = true
                        added.addAll(list)
                        // If Reddit returned an empty page, don't spin on the same page.
                        if (list.isEmpty() && next.isEmpty()) s.done = true
                    } catch (redditError: Exception) {
                        val message = redditError.message.orEmpty()
                        if (message.contains("403") || message.contains("429") || message.contains("Forbidden", true)) {
                            val (fallback, last) = Api.commons(s.q, s.page)
                            s.page++
                            if (last) s.done = true
                            added.addAll(fallback)
                        } else throw redditError
                    }
                }
            } catch (e: Exception) {
                val m = e.message ?: ""
                s.err = when {
                    m.contains("429") -> "Reddit is rate-limiting requests (HTTP 429), and the fallback source could not load. Tap to retry."
                    m.contains("403") -> "Reddit refused the request, and the fallback source could not load. Check your connection and retry."
                    m.contains("404") -> "This Reddit feed was not found (HTTP 404)."
                    m.contains("UnknownHost") || m.contains("timeout", true) || m.contains("Unable to resolve", true) -> "Network unavailable. Check your internet and retry."
                    else -> "Couldn’t load photos ($m). Tap to retry."
                }
            }
            runOnUiThread {
                s.loading = false
                val fresh = added.filter { s.ids.add(it.id) }
                val start = s.items.size
                s.items.addAll(fresh)
                if (s === cur && tab == 0) {
                    adapter.notifyItemRangeInserted(start, fresh.size)
                    updateStatus()
                    rv.post { if (!rv.canScrollVertically(1)) loadMore() }
                }
            }
        }.start()
    }

    inner class PhotoAdapter : RecyclerView.Adapter<PhotoAdapter.VH>() {
        var data: List<Photo> = ArrayList()

        inner class VH(val root: View) : RecyclerView.ViewHolder(root) {
            val img: ImageView = root.findViewById(R.id.img)
            val lbl: TextView = root.findViewById(R.id.lbl)
            val heart: TextView = root.findViewById(R.id.heart)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_photo, parent, false)
            v.layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                setMargins(0, 8.dp(), 0, 12.dp())
            }
            return VH(v)
        }

        override fun getItemCount() = data.size

        override fun onBindViewHolder(h: VH, pos: Int) {
            val p = data[pos]
            h.lbl.text = p.credit.ifBlank { "Photographer" }
            h.heart.text = if (Store.isFav(this@MainActivity, p.id)) "♥" else "♡"
            val screenWidth = Resources.getSystem().displayMetrics.widthPixels - 36.dp()
            val ratio = if (p.width > 0 && p.height > 0) p.height.toFloat() / p.width.toFloat() else 1.18f
            val desiredHeight = (screenWidth * ratio).toInt().coerceIn(190.dp(), 650.dp())
            h.img.layoutParams = h.img.layoutParams.apply { height = desiredHeight }
            h.img.setBackgroundColor(p.color)
            val streamQuality = getSharedPreferences("drishyam_settings", MODE_PRIVATE).getString("stream_quality", "Auto") ?: "Auto"
            val targetWidth = when (streamQuality) { "Standard" -> 480; "High" -> 1200; else -> Resources.getSystem().displayMetrics.widthPixels }
            val targetHeight = (targetWidth * ratio).toInt().coerceIn(240, 2400)
            val streamUrl = if (streamQuality == "High") p.full else p.thumb
            Glide.with(h.img).load(streamUrl).override(targetWidth, targetHeight).centerCrop().into(h.img)
            h.heart.setOnClickListener {
                val liked = Store.toggle(this@MainActivity, p)
                if (tab == 1) { data = Store.favs(this@MainActivity); notifyDataSetChanged(); updateStatus() }
                else h.heart.text = if (liked) "♥" else "♡"
            }
            h.root.setOnClickListener {
                startActivity(Intent(this@MainActivity, ViewerActivity::class.java).putExtra("p", p.toJson().toString()))
            }
        }
    }
}
