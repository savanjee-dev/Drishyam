Drishyam by Savan - Android project (updated source package)

Build: upload the CONTENTS of this ZIP to a GitHub repository (including the hidden .github folder), then open Actions and run Build APK. Download Drishyam-APK from the completed run.

Changes in this package:
- Added r/incredibleindia as a Reddit category.
- Improved network response diagnostics so HTTP 403 and 429 are distinguishable.
- Updated the Reddit request User-Agent and JSON Accept header.
- The About page remains a scrollable profile page.

Important limitations:
- Reddit may still deny requests with HTTP 403/429; changing headers cannot guarantee access. Use Reddit's supported API access method if those responses persist.
- Shared developer photo publishing is NOT yet implemented. It needs a secure upload service/backend and a shared gallery database. Do not put Cloudinary API Secret in the APK.
- Unsplash is optional and disabled until an Access Key is configured in app/src/main/java/com/savan/drishyam/Data.kt.

Fonts: Erica One and Nothing You Could Do (SIL Open Font License, see LICENSES).
