# Drishyam v3.0.0 — Phase 2 private debug validation

- Version metadata: `3.0.0` / versionCode `46`.
- This is an unreleased, private working snapshot. It does not publish a release.
- Developers page is unchanged; Phase 3 and later phases are not included.
- Run the GitHub Actions workflow `Verify Drishyam Phase 2 Debug APK` manually in a PRIVATE repository to build and retain a debug APK artifact for 14 days.
- Workflow builds `assembleDebug` only; no release signing or publishing step exists.
- XML/static validation is not equivalent to a successful Gradle build or device QA. Do not mark Phase 2 complete until the debug build and runtime checks pass.
